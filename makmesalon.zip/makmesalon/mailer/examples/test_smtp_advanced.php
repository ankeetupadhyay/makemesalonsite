<html>
<head>
<title>PHPMailer - SMTP advanced test with authentication</title>
</head>
<body>

<?php

require_once('../class.phpmailer.php');
include("../class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "developmentmediaworld@gmail.com";
$mail->Password = "mediaworld";
// $mail->SetFrom("heramb@yopmail.com");
$mail->AddCC("romi@yopmail.com"); // This will send mail to user
$mail->Subject = "Test";
$mail->Body = "hello";
$mail->AddAddress("heramb@mediaworldlimited.co");
$mail->MsgHTML(file_get_contents('contents.html'));
$mail->AddAttachment('images/phpmailer.gif');      // attachment
$mail->AddAttachment('images/phpmailer_mini.gif'); 

 if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo "Message has been sent";
 }
?>

</body>
</html>
